<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
	protected $table = "banner";
	protected $fillable =
	[
		'titulo',
		'linkbanner',
		'imgbanner',
		'imgmobile'
	];
}